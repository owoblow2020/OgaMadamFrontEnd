self.__precacheManifest = [
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/ogamadam/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "5e77d845c730f000ca11",
    "url": "/ogamadam/static/js/runtime~main.5e77d845.js"
  },
  {
    "revision": "8bbca3e6d0c484ce8b1b",
    "url": "/ogamadam/static/js/main.8bbca3e6.chunk.js"
  },
  {
    "revision": "e7555df7a21544153354",
    "url": "/ogamadam/static/js/1.e7555df7.chunk.js"
  },
  {
    "revision": "8bbca3e6d0c484ce8b1b",
    "url": "/ogamadam/static/css/main.2f29b75e.chunk.css"
  },
  {
    "revision": "6228f713abd5cfd4ffed4678a6e7f381",
    "url": "/ogamadam/index.html"
  }
];